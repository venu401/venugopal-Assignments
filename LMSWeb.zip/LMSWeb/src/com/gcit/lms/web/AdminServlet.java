package com.gcit.lms.web;


import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.descriptor.tld.TldRuleSet.Variable;

import com.gcit.lms.domain.Author;
import com.gcit.lms.domain.Book;
import com.gcit.lms.domain.Genre;
import com.gcit.lms.domain.Publisher;
import com.gcit.lms.service.AdministrativeService;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet({ "/addAuthor", "/addGenre","/addPublisher","/addBook" })
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public AdminServlet() {
		super();
		// TODO Auto-generated constructor stub
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String reqUrl = request.getRequestURI().substring(request.getContextPath().length(),
				request.getRequestURI().length());
		switch (reqUrl) {
		case "/addAuthor":
				String authorName = request.getParameter("authorName");
				AdministrativeService service = new AdministrativeService();
				Author author = new Author();
				author.setAuthorName(authorName);
				try {
					service.createAuthor(author);
					request.setAttribute("message", "Author added sucessfully");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					request.setAttribute("message", "Author failed sucessfully");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				RequestDispatcher rd = request.getRequestDispatcher("admin.jsp");
				rd.forward(request, response);
			
			break;


			
		case "/addGenre":
				String genre_name = request.getParameter("GenreName");
				AdministrativeService serviceGenre = new AdministrativeService();
				Genre genre = new Genre();
				genre.setGenre_name(genre_name);
				try {
					serviceGenre.createGenre(genre);
					request.setAttribute("message", "genre added sucessfully");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					request.setAttribute("message", "genre failed !!");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				RequestDispatcher rdGenre = request.getRequestDispatcher("admin.jsp");
				rdGenre.forward(request, response);
			
			break;
		case "/addPublisher":
			String publisherName = request.getParameter("PublisherName");
			String publisherAddress = request.getParameter("PublisherAddress");
			String publisherPhone = request.getParameter("PublisherPhone");
			
			AdministrativeService servicepublisher = new AdministrativeService();
			Publisher publisher = new Publisher();
			publisher.setPublisherName(publisherName);
			publisher.setPublisherAddress(publisherAddress);
			publisher.setPublisherPhone(publisherPhone);
			try {
				servicepublisher.createPublisher(publisher);
				request.setAttribute("message", "publisher added sucessfully");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.setAttribute("message", "publisher failed failed !!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher rdpublisher = request.getRequestDispatcher("admin.jsp");
			rdpublisher.forward(request, response);
		
		break;
		
			
		}	
	}
}
