package com.gcit.lms.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gcit.lms.domain.Genre;

//import com.lms.entity.Author;
//import com.lms.entity.Geners;

public class GenreDAO extends BaseDAO{
	public GenreDAO(Connection conn) {
		super(conn);
	}

	public void insertGenre(Genre  genre) throws ClassNotFoundException, SQLException{
		save("insert into tbl_genre (genre_Name) values (?)", new Object[] {genre.getGenre_name()});
	}
	
	public void deleteAuthor(Genre  genre) throws ClassNotFoundException, SQLException{
		save("delete from tbl_genre where genre_Id=?", new Object[] {genre.getGenre_id()});
	}
	
	public void deleteAll() throws ClassNotFoundException, SQLException{
		save("delete * from tbl_genre", null);
	}
	
	public void updateGenre(Genre genre) throws ClassNotFoundException, SQLException{
		save("update  tbl_genre set genre_Name = ? where genre_Id = ?", new Object[] {genre.getGenre_name(), genre.getGenre_id()});
	}
	
	public List<Genre> readAll() throws ClassNotFoundException, SQLException{
	    return read("select * from tbl_genre", null);
	    
	}

	@Override
	public List<Genre> extractData(ResultSet rs) throws SQLException {
		List<Genre> genre = new ArrayList<Genre>();
		while(rs.next()){
			Genre g = new Genre();
			g.setGenre_id(rs.getInt("Genre_Id"));
			g.setGenre_name(rs.getString("Genre_Name"));
			
			genre.add(g);
		}
		return genre;
	}

	@Override
	public List<?> extractDataFirstLevel(ResultSet rs) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}


